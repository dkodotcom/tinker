﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Papa_Bobs_Pizza_Challenge
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void babyBobRadioButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void mamaBobRadioButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void papaBobRadioButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void thinCrustRadioButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void deepDishRadioButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void peppCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void onionsCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void gpCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void rpCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void anchoviesCheckBox_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void purchaseButton_Click(object sender, EventArgs e)
        {
            double total;

            if (babyBobRadioButton.Checked) total = 10.00;
            else if (mamaBobRadioButton.Checked) total = 13.00;
            else total = 16.00;

            if (deepDishRadioButton.Checked) total += 2.00;

            total = (peppCheckBox.Checked) ? total + 1.5 : total;
            total = (onionsCheckBox.Checked) ? total + 0.75 : total;
            total = (gpCheckBox.Checked) ? total + 0.50 : total;
            total = (rpCheckBox.Checked) ? total + 0.75 : total;
            total = (anchoviesCheckBox.Checked) ? total + 2.00 : total;

            if ((peppCheckBox.Checked && gpCheckBox.Checked && anchoviesCheckBox.Checked) || (peppCheckBox.Checked && rpCheckBox.Checked && onionsCheckBox.Checked))
            {
                total -= 2.00;
            }

            totalLabel.Text = "$ " + total.ToString();

        }
    }
}