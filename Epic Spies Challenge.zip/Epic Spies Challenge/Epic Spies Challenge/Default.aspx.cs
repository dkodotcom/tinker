﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Epic_Spies_Challenge
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                endCalendar.SelectedDate = DateTime.Now.Date;
                startCalendar.SelectedDate = DateTime.Now.Date.AddDays(14);
                projectedCalendar.SelectedDate = DateTime.Now.Date.AddDays(21);
            }
        }

        protected void spyCodeTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        protected void newNameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        protected void endCalendar_SelectionChanged(object sender, EventArgs e)
        {

        }

        protected void startCalendar_SelectionChanged(object sender, EventArgs e)
        {

        }

        protected void projectedCalendar_SelectionChanged(object sender, EventArgs e)
        {

        }

        protected void assignSpyButton_Click(object sender, EventArgs e)
        {
            string spyName = spyCodeTextBox.Text;
            string newAssignment = newNameTextBox.Text;

            TimeSpan totalAssignmentTime = projectedCalendar.SelectedDate.Subtract(startCalendar.SelectedDate);
            double totalCost = totalAssignmentTime.TotalDays * 500.0;

            // If assignment is > 21 days, add $1,000

            if (totalAssignmentTime.TotalDays > 21)
            { 
                totalCost += 1000.0;
            }

            resultLabel.Text = String.Format("Assignment of {0} to assignment {1} is authorized. Budget total: {2:C}", spyName, newAssignment, totalCost);

            TimeSpan timeBetweenAssignments = startCalendar.SelectedDate.Subtract(endCalendar.SelectedDate);
            if (timeBetweenAssignments.TotalDays < 14)
            {
                resultLabel.Text = "Error: Must allow at least two weeks between previous assignment and new assignment.";

                DateTime earliestNewAssignmentDate = endCalendar.SelectedDate.AddDays(14);

                startCalendar.SelectedDate = earliestNewAssignmentDate;
                startCalendar.VisibleDate = earliestNewAssignmentDate;
            }
        }
    }
}